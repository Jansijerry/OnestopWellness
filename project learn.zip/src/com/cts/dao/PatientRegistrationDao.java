package com.cts.dao;

import com.cts.model.PatientRegistrationModel;

public interface PatientRegistrationDao {


public int insertDiagnosis(PatientRegistrationModel model1);
public PatientRegistrationModel getReport(int user_id);
}
