package com.cts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cts.model.ConnectionFactory;
import com.cts.model.HospitalRegistrationModel;


public class HospitalRegistrationDaoImpl implements HospitalRegistrationDao {	
	Connection connection=null;
	PreparedStatement pStatement=null;
	public HospitalRegistrationDaoImpl() {
		// TODO Auto-generated constructor stub
		connection=ConnectionFactory.createCon();
	}
	public int register(HospitalRegistrationModel model) {
		// TODO Auto-generated method stub
		int count=0;
		try{
	
			//Step 3: write your query
			String insertQuery="insert into hospital_registration_table values(?,?,?,?,?,?,?,?,?,?,?)";	
			pStatement=connection.prepareStatement(insertQuery);
			
			//step 4:set the data
			pStatement.setInt(1, model.getHospital_id());
			pStatement.setString(2, model.getHospital_name());
			pStatement.setString(3, model.getAddr_line1());
			pStatement.setString(4, model.getAddr_line2());
			pStatement.setString(5, model.getCity());
			pStatement.setString(6, model.getState());
			pStatement.setInt(7,model.getPin());
			pStatement.setInt(8, model.getCertification());
			pStatement.setString(9, model.getSucc_operation());
			pStatement.setInt(10, model.getAchievement());
			pStatement.setString(11, "null");
			count=pStatement.executeUpdate();
        }catch (Exception e) {
                        System.out.println("Error in Insert doctor "+e);
        }
        return count;
			
		}	
	
	public int UpdateHospitalStatus(String status,int hid)
	{
		int return_status=0;
		try {
			
			
			
			PreparedStatement ps=connection.prepareStatement("update hospital_registration_table set status=? where HospitalId=?");
			ps.setString(1, status);
			ps.setInt(2, hid);
			return_status=ps.executeUpdate();
		}catch (Exception e) {
			// TODO: handle exception
		}
		return return_status;
	}

}
