package com.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cts.model.ConnectionFactory;
import com.cts.model.DoctorModel;

public class DoctorDaoImpl implements DoctorDao{
	
	Connection connection=null;
	PreparedStatement pStatement=null;
	public DoctorDaoImpl() {
		// TODO Auto-generated constructor stub
		connection=ConnectionFactory.createCon();
	}
	@Override
	public int register(DoctorModel model) {
		// TODO Auto-generated method stub
		int count=0;
        try {
        	
                        PreparedStatement ps=connection.prepareStatement("insert into doctor_table(doctorid,doctorname,specialization,hospitalname) values(?,?,?,?)");
                        ps.setInt(1, model.getDoctorid());
                        ps.setString(2, model.getDoctorname());
                        ps.setString(3, model.getSpecialization());
                        ps.setString(4, model.getHospitalname());
                        count=ps.executeUpdate();
        }catch (Exception e) {
                        System.out.println("Error in Insert doctor "+e);
        }
        return count;
	}
	@Override
	public List<DoctorModel> showAllAvailable(String hospital_name) {
		// TODO Auto-generated method stub
		List<DoctorModel> availableList=new ArrayList<DoctorModel>();
		try {
			PreparedStatement st=connection.prepareStatement("select * from doctor_table where hospitalname=?");
			st.setString(1, hospital_name);
			ResultSet rs=st.executeQuery();
			
			while(rs.next())
			{
				DoctorModel dr=new DoctorModel();
				dr.setDoctorid(rs.getInt(1));
				dr.setDoctorname(rs.getString(2));
				dr.setSpecialization(rs.getString(3));
				dr.setHospitalname(rs.getString(4));
				dr.setSlot1(rs.getString(5));
				dr.setSlot2(rs.getString(6));
				dr.setSlot3(rs.getString(7));
				dr.setSlot4(rs.getString(8));
				availableList.add(dr);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	
	return availableList;
	}
	@Override
	public String getHospitalNameById(int hospital_id) {
		// TODO Auto-generated method stub
		String hospital_name=null;
		try {
			PreparedStatement st=connection.prepareStatement("select HospitalName from hospital_registration_table where HospitalId=?");
			st.setInt(1, hospital_id);
			ResultSet rs=st.executeQuery();
			
			if(rs.next())
			{
				hospital_name=rs.getString(1);
			}			
		} catch (Exception e) {
			// TODO: handle exception
		}
		return hospital_name;
	}
	@Override
	public int updateDoctor(int doctor_id, String status, int statusno) {
		// TODO Auto-generated method stub
		int count=0;
		 try {
			 
            PreparedStatement ps=connection.prepareStatement("update doctor_table set status?=? where doctorid=?");
            ps.setInt(1, statusno);
            ps.setString(2, status);
            ps.setInt(3, doctor_id); 
            count=ps.executeUpdate();
     }catch (Exception e) {
            System.out.println("Error in Updating hospital status"+e);
            count=0;
     }
     return count;
	}

}
