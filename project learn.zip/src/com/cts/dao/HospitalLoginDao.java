package com.cts.dao;

import com.cts.model.HospitalLoginModel;

public interface HospitalLoginDao {
	public boolean register(HospitalLoginModel model);
}
