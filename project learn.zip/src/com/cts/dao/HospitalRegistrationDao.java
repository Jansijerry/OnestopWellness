package com.cts.dao;


import com.cts.model.HospitalRegistrationModel;



public interface HospitalRegistrationDao {
	public int register(HospitalRegistrationModel model);
	public int UpdateHospitalStatus(String status,int hid);
}
