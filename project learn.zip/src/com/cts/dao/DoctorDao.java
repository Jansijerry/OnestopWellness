package com.cts.dao;

import java.util.List;

import com.cts.model.DoctorModel;

public interface DoctorDao {
	public int register(DoctorModel model);
	public List<DoctorModel> showAllAvailable(String hospital_name);
	public String getHospitalNameById(int hospital_id);
	public int updateDoctor(int doctor_id,String slot,int slotno);
}
