package com.cts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cts.model.UserRegistrationModel;

public class UserRegistrationDaoImpl implements UserRegistrationDao {
	private final String db_username="root";
	private final String db_password="root";
	private final String db_driverClass="com.mysql.jdbc.Driver";
	private final String db_url="jdbc:mysql://localhost:3306/project";
	Connection connection=null;
	PreparedStatement pStatement=null;
	@Override
	public void register(UserRegistrationModel model) {
		// TODO Auto-generated method stub
		try{
			//Step 1:load the driver
			Class.forName(db_driverClass);
			
			//Step 2:get the connection
			connection=DriverManager.getConnection(db_url,db_username,db_password);
			
			//Step 3: write your query
			String insertQuery="insert into user_registration_table values(?,?,?,?,?,?,?,?,?,?)";	
			pStatement=connection.prepareStatement(insertQuery);
			
			//step 4:set the data
			pStatement.setInt(1, model.getUserId());
			pStatement.setString(2, model.getFirstName());
			pStatement.setString(3, model.getLastName());
			pStatement.setInt(4, model.getAge());
			pStatement.setString(5, model.getGender());
			pStatement.setString(6, model.getContactNumber());
			pStatement.setString(7,model.getAddress());
			pStatement.setString(8, model.getCity());
			pStatement.setString(9, model.getZipcode());
			pStatement.setString(10, model.getPassword());
			
			//step 5:execute your statement
			pStatement.execute();
			
			System.out.println("Data has been successfully inserted.");
			
			
		}catch(Exception exception){
			exception.printStackTrace();
		}finally{
			if(pStatement!=null){
				try
				{
				pStatement.close();
				}catch(SQLException e)
				{
					e.printStackTrace();
				}
			}
			if(connection!=null)
			{
				try
				{
					connection.close();
				}catch(SQLException e)
				{
					e.printStackTrace();
				}
			}
		}
		

		
	}

}
