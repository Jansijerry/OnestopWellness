package com.cts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;

import com.cts.model.ConnectionFactory;
import com.cts.model.PatientRegistrationModel;

public class PatientRegistrationDaoImpl implements PatientRegistrationDao{
	
	Connection connection=null;
	PreparedStatement pStatement=null;
	public PatientRegistrationDaoImpl() {
		// TODO Auto-generated constructor stub
		connection=ConnectionFactory.createCon();
	}
	@Override
	public int insertDiagnosis(PatientRegistrationModel model1) {
		// TODO Auto-generated method stub
		int count=0;
        try {
        	

                        PreparedStatement ps=connection.prepareStatement("insert into patient_registration_table values(?,?,?,?,?,?)");
                        ps.setInt(1, model1.getPatientid());
                        ps.setString(2, model1.getDisease());
                        ps.setString(3, model1.getPrescriptionprovided());
                        ps.setInt(4, model1.getPatientid());
                        ps.setDate(5, new java.sql.Date(model1.getDatetime().getTime()));
                        ps.setInt(6, model1.getHospitalid());
                        count=ps.executeUpdate();
                        System.out.println(count+" Patient Report inserted");
        }catch (Exception e) {
                        System.out.println("Error in Insert diagnosis "+e);
        }
        return count;
	}
	@Override
	public PatientRegistrationModel getReport(int user_id) {
		// TODO Auto-generated method stub
		PatientRegistrationModel d=null;
		try {			
            PreparedStatement ps=connection.prepareStatement("select * from patient_registration_table where patient_id=?");
            ps.setInt(1, user_id);            
            ResultSet rs=ps.executeQuery();
            if(rs.next())
            {
            	d=new PatientRegistrationModel(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getDate(5), rs.getInt(6));
            	System.out.println("Data Written...");
            }              
		}catch (Exception e) {
            System.out.println("Error in get  Patient Report "+e);
}
		return d;
	}
	}


