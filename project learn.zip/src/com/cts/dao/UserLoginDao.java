package com.cts.dao;

import com.cts.model.UserLoginModel;

public interface UserLoginDao {
	public boolean register(UserLoginModel model);
}
