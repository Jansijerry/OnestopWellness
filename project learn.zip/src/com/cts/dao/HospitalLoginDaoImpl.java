package com.cts.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cts.model.HospitalLoginModel;

public class HospitalLoginDaoImpl implements HospitalLoginDao {
	
	private final String db_username="root";
	private final String db_password="root";
	private final String db_driverClass="com.mysql.jdbc.Driver";
	private final String db_url="jdbc:mysql://localhost:3306/project";
	Connection connection=null;
	PreparedStatement pStatement=null;
	boolean result=false;
	@Override
	public boolean register(HospitalLoginModel model) {
		// TODO Auto-generated method stub
		try{
			//Step 1:load the driver
			Class.forName(db_driverClass);
			
			//Step 2:get the connection
			connection=DriverManager.getConnection(db_url,db_username,db_password);
			
			//Step 3: write your query
			String insertQuery="select * from hospital_registration_table where HospitalId=? and HospitalName=? and status='Approved'";	
			pStatement=connection.prepareStatement(insertQuery);
			
			//step 4:set the data
			pStatement.setInt(1, model.getHospitalId());
			pStatement.setString(2, model.getHospitalName());
			
			//step 5:execute your statement
			ResultSet resultSet=pStatement.executeQuery();
			result=resultSet.next();
			
			if(result==true){
				System.out.println("login success");
				}else{
					System.out.println("login failed");
				}
			
			
		}catch(Exception exception){
			exception.printStackTrace();
		}finally{
			if(pStatement!=null){
				try
				{
				pStatement.close();
				}catch(SQLException e)
				{
					e.printStackTrace();
				}
			}
			if(connection!=null)
			{
				try
				{
					connection.close();
				}catch(SQLException e)
				{
					e.printStackTrace();
				}
			}
		}

		return result;
	}
	
}
