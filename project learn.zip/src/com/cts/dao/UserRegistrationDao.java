package com.cts.dao;

import com.cts.model.UserRegistrationModel;

public interface UserRegistrationDao {
	
	public void register(UserRegistrationModel model);
	
}
