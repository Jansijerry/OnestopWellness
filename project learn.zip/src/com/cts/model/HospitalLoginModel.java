package com.cts.model;

public class HospitalLoginModel {
	private int hospitalid;
	private String hospitalname;
	public int getHospitalId() {
		return hospitalid;
	}
	public void setHospitalId(int hospitalid) {
		this.hospitalid = hospitalid;
	}
	public String getHospitalName() {
		return hospitalname;
	}
	public void setHospitalName(String hospitalName) {
		this.hospitalname = hospitalName;
	}

}
