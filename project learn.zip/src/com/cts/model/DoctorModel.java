package com.cts.model;

public class DoctorModel {
	private int doctorid;
	private String doctorname;
	private String specialization;
	private String hospitalname;
	private String slot1;
	private String slot2;
	private String slot3;
	private String slot4;
	public String getSlot1() {
		return slot1;
	}
	public void setSlot1(String slot1) {
		this.slot1 = slot1;
	}
	public String getSlot2() {
		return slot2;
	}
	public void setSlot2(String slot2) {
		this.slot2 = slot2;
	}
	public String getSlot3() {
		return slot3;
	}
	public void setSlot3(String slot3) {
		this.slot3 = slot3;
	}
	public String getSlot4() {
		return slot4;
	}
	public void setSlot4(String slot4) {
		this.slot4 = slot4;
	}
	public int getDoctorid() {
		return doctorid;
	}
	public void setDoctorid(int doctorid) {
		this.doctorid = doctorid;
	}
	public String getDoctorname() {
		return doctorname;
	}
	public void setDoctorname(String doctorname) {
		this.doctorname = doctorname;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public String getHospitalname() {
		return hospitalname;
	}
	public void setHospitalname(String hospitalname) {
		this.hospitalname = hospitalname;
	}
	public DoctorModel() {
		// TODO Auto-generated constructor stub
	}
		
	
	public DoctorModel(int doctorid, String doctorname, String specialization, String hospitalname) {
		// TODO Auto-generated constructor stub
		this.doctorid = doctorid;
		this.doctorname = doctorname;
		this.specialization = specialization;
		this.hospitalname = hospitalname;
	}
}
