package com.cts.model;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionFactory {
	
	private final static String db_username="root";
	private final static String db_password="root";
	private final static String db_driverClass="com.mysql.jdbc.Driver";
	private final static String db_url="jdbc:mysql://localhost:3306/project";
	static Connection con=null;
	public static Connection createCon()
	{
		try {
			
			Class.forName(db_driverClass);
			
			//Step 2:get the connection
			con=DriverManager.getConnection(db_url,db_username,db_password);
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error in Create Connection : "+e);
		}
		return con;
	}

}
