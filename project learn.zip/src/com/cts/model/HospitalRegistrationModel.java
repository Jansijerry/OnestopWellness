package com.cts.model;

public class HospitalRegistrationModel {

	private int Hospital_id;
	private String Hospital_name;
	private String addr_line1;
	private String addr_line2;
	private String city;
	private String state;
	private int pin;
	private int certification;
	private String Succ_operation;
	private int achievement;
	public HospitalRegistrationModel(int hospital_id, String hospital_name, String addr_line1, String addr_line2,
			String city, String state, int pin, int certification, String success_operation, int achievement) {
		// TODO Auto-generated constructor stub
		Hospital_id = hospital_id;
		Hospital_name = hospital_name;
		this.addr_line1 = addr_line1;
		this.addr_line2 = addr_line2;
		this.city = city;
		this.state = state;
		this.pin = pin;
		this.certification = certification;
		Succ_operation = success_operation;
		this.achievement = achievement;
	}
	public int getHospital_id() {
		return Hospital_id;
	}
	public void setHospital_id(int hospital_id) {
		Hospital_id = hospital_id;
	}
	public String getHospital_name() {
		return Hospital_name;
	}
	public void setHospital_name(String hospital_name) {
		Hospital_name = hospital_name;
	}
	public String getAddr_line1() {
		return addr_line1;
	}
	public void setAddr_line1(String addr_line1) {
		this.addr_line1 = addr_line1;
	}
	public String getAddr_line2() {
		return addr_line2;
	}
	public void setAddr_line2(String addr_line2) {
		this.addr_line2 = addr_line2;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public int getCertification() {
		return certification;
	}
	public void setCertification(int certification) {
		this.certification = certification;
	}
	public String getSucc_operation() {
		return Succ_operation;
	}
	public void setSucc_operation(String succ_operation) {
		Succ_operation = succ_operation;
	}
	public int getAchievement() {
		return achievement;
	}
	public void setAchievement(int achievement) {
		this.achievement = achievement;
	}
}
