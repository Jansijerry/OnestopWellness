package com.cts.model;

import java.util.Date;

public class PatientRegistrationModel {
	private int patientid;
	private String disease;
	private String prescriptionprovided;
	private int doctorid;
	private Date datetime;
	private int hospitalid;
	public PatientRegistrationModel(int patientid, String disease, String prescriptionprovided, int doctorid,
			Date datetime, int hospitalid) {
		// TODO Auto-generated constructor stub
		this.patientid = patientid;
		this.disease = disease;
		this.prescriptionprovided = prescriptionprovided;
		this.doctorid = doctorid;
		this.datetime = datetime;
		this.hospitalid = hospitalid;
	}
	public int getHospitalid() {
		return hospitalid;
	}
	public void setHospitalid(int hospitalid) {
		this.hospitalid = hospitalid;
	}
	public int getPatientid() {
		return patientid;
	}
	public void setPatientid(int patientid) {
		this.patientid = patientid;
	}
	public String getDisease() {
		return disease;
	}
	public void setDisease(String disease) {
		this.disease = disease;
	}
	public String getPrescriptionprovided() {
		return prescriptionprovided;
	}
	public void setPrescriptionprovided(String prescriptionprovided) {
		this.prescriptionprovided = prescriptionprovided;
	}
	public int getDoctorid() {
		return doctorid;
	}
	public void setDoctorid(int doctorid) {
		this.doctorid = doctorid;
	}
	public Date getDatetime() {
		return datetime;
	}
	public void setDatetime(Date datetime) {
		this.datetime = datetime;
	}
	
}
