package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.dao.HospitalRegistrationDaoImpl;

/**
 * Servlet implementation class UpdateHospitalStatus
 */
@WebServlet("/UpdateHospitalStatus")
public class UpdateHospitalStatus extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateHospitalStatus() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		String status=request.getParameter("status");		
		int hid=Integer.parseInt(request.getParameter("hid"));
		
		HospitalRegistrationDaoImpl hrd=new HospitalRegistrationDaoImpl();
		int ret_status=hrd.UpdateHospitalStatus(status,hid);
		if(ret_status==1)
		{
			pw.print("<center><h2 style=color:green>Hospital Approved</h2></center>");
			request.getRequestDispatcher("DashBoard.jsp").include(request, response);
		}
		else {
			pw.print("<center><h2 style=color:green>Hospital Denied</h2></center>");
			request.getRequestDispatcher("DashBoard.jsp").include(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
