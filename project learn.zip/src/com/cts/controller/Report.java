package com.cts.controller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.dao.PatientRegistrationDao;
import com.cts.dao.PatientRegistrationDaoImpl;
import com.cts.model.PatientRegistrationModel;

/**
 * Servlet implementation class Report
 */
@WebServlet("/Report")
public class Report extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Report() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("application/pdf;charset=UTF-8");		
        response.addHeader("Content-Disposition", "inline; filename=" + "patientreport.pdf");
        ServletOutputStream out = response.getOutputStream();
        HttpSession hs=request.getSession();
        int user_id1=(Integer)hs.getAttribute("UserId");
       // int user_id=Integer.parseInt(user_id1);
        PatientRegistrationDao dd= new PatientRegistrationDaoImpl();
        PatientRegistrationModel dignosis = dd.getReport(user_id1);

        if(dignosis!=null)
        {
        ByteArrayOutputStream baos = Pdf.getPdfFile1(dignosis);
        baos.writeTo(out);
        }else
        {
        	System.out.println("Report Not Found");
        	//pw.print("Report Not Found...Contact Hospital Admin");
        	//request.getRequestDispatcher("Home_Page.jsp").include(request, response);
        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
