package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.dao.PatientRegistrationDao;
import com.cts.dao.PatientRegistrationDaoImpl;
import com.cts.model.PatientRegistrationModel;

@WebServlet("/PatientRegistrationServlet")
public class PatientRegistrationServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
 	public void init() throws ServletException {
 		System.out.println("Servlet Initialization");
 	}
 
 	
 	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	//Step 1 set the content type like html or xml or pdf or text or doc
	response.setContentType("text/html");

	
	//Step 2 create an out object using printWriter class
	PrintWriter out=response.getWriter();
	
	
	//Step 3 get the parameters from html/jsp form using getparameter
	int patientid=Integer.parseInt(request.getParameter("patientid"));
	String disease=request.getParameter("disease");
	String prescriptionprovided=request.getParameter("prescriptionprovided");
	int doctorid=Integer.parseInt(request.getParameter("doctorid"));
	String datetime=request.getParameter("datetime");
	System.out.println(datetime);
	SimpleDateFormat sd=new SimpleDateFormat("yyyy-MM-dd");
	java.util.Date dd=null;
	try {
		dd = sd.parse(datetime);
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("Error in Insert Dign Controller : "+e);
	}
	int hospitalid=Integer.parseInt(request.getParameter("hospitalid"));
	PatientRegistrationModel model1=new PatientRegistrationModel(patientid,disease,prescriptionprovided,doctorid,dd,hospitalid);
	PatientRegistrationDao dao=new PatientRegistrationDaoImpl();
	int count=dao.insertDiagnosis(model1);
    if(count==1)
    {
    	 out.println("<center><h2 style='color:green;'>Added Successfully</h2></center>");
         request.getRequestDispatcher("HospitalDashBoard.jsp").include(request, response);
                  
    }
    else
    {
                    out.println("Failed Adding");
    }
 	}


 	public void destroy() 
 	{
	System.out.println("Destroy server or close the server");
	}

}
