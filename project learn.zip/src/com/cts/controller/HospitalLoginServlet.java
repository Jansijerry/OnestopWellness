package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.model.HospitalLoginModel;
import com.cts.service.HospitalLoginService;
import com.cts.service.HospitalLoginServiceImpl;

@WebServlet("/HospitalLoginServlet")
public class HospitalLoginServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
	public void init() throws ServletException {
 		System.out.println("Servlet Initialization");
 	}	

 	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
 
		//step-1: set the content type like html/xml/text/pdf/doc
				response.setContentType("text/html");
				
				//step-2: create an out object using PrintWriter class
				PrintWriter out=response.getWriter();
				
				//step-3:get the parameters from html or jsp form using getParameter()
				int hospitalid=Integer.parseInt(request.getParameter("hospitalid"));
				String hospitalname=request.getParameter("hospitalname");
				
				RequestDispatcher requestDispatcher;
				HttpSession httpSession;
				
					//step-4: Create an object for POJO/Model class and set the values
					HospitalLoginModel model=new HospitalLoginModel();
					model.setHospitalId(hospitalid);
					model.setHospitalName(hospitalname);
					
					//step-6:call service layer for database 
					HospitalLoginService service=new HospitalLoginServiceImpl();
					boolean result=service.register(model);
					
					
					
					if(result==true){
						//we can access details in second servlet from first servlet using session
						httpSession=request.getSession();
						httpSession.setAttribute("hospitalid", hospitalid);
						httpSession.setAttribute("hospitalname", hospitalname);
						
						//forward to next servlet or jsp or html using RequestDispatcher
						requestDispatcher=request.getRequestDispatcher("HospitalLoginSuccessServlet");
						requestDispatcher.forward(request, response);
					//out.print("Login Success");
					}else{
						out.print("Login failed");
						//System.out.println(userId+"   "+password);
						requestDispatcher=request.getRequestDispatcher("HospitalLogin.jsp");
						requestDispatcher.include(request, response);
						
					}
				}

}
