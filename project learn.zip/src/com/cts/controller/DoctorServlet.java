package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.dao.DoctorDao;
import com.cts.dao.DoctorDaoImpl;
import com.cts.model.DoctorModel;

/**
 * Servlet implementation class DoctorServlet
 */
@WebServlet("/DoctorServlet")
public class DoctorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DoctorServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		int doctor_id=Integer.parseInt(request.getParameter("doctorid"));
        String doctor_name=request.getParameter("doctorname");
        String specialization=request.getParameter("specialization");
        String Hospital_Name=request.getParameter("hospitalname");
        DoctorModel dr=new DoctorModel(doctor_id, doctor_name,specialization,Hospital_Name);
        try {
        DoctorDao drdao=new DoctorDaoImpl();
        int count=drdao.register(dr);
        if(count==1)
        {
                        pw.println("<center><h2 style='color:green;'>Added Successfully</h2></center>");
                        request.getRequestDispatcher("HospitalDashBoard.jsp").include(request, response);
                        System.out.println("Added ");

        }
        else
        {
                        pw.println("Failed Adding");
                        request.getRequestDispatcher("AddDoctor.jsp").include(request, response);
                        System.out.println("Failed");
        }
        }catch (Exception e) {
			// TODO: handle exception
        	System.out.println("Error in Insert Doctor COntroller : "+e);
		}
	}

}
