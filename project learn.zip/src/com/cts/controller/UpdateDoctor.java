package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cts.dao.DoctorDao;
import com.cts.dao.DoctorDaoImpl;
import com.cts.model.DoctorModel;

/**
 * Servlet implementation class UpdateDoctor
 */
@WebServlet("/UpdateDoctor")
public class UpdateDoctor extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateDoctor() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		String status=null;		
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		int doctor_id=Integer.parseInt(request.getParameter("doctorid"));
		int statusno=Integer.parseInt(request.getParameter("status"));
		if(statusno==1)
		{
			status=request.getParameter("status1");
		}
		else if(statusno==2)
		{
			status=request.getParameter("status2");
		}
		else if(statusno==3)
		{
			status=request.getParameter("status3");
		}
		else if(statusno==4)
		{
			status=request.getParameter("status4");
		}
		DoctorDao drd=new DoctorDaoImpl();
		int count=drd.updateDoctor(doctor_id,status,statusno);
		
		if(count==1)
		{
			HttpSession hs=request.getSession();
			String hospital_name=(String)hs.getAttribute("hname");
			System.out.println(hospital_name);
			DoctorDao dro=new DoctorDaoImpl();
			List<DoctorModel> availableList=dro.showAllAvailable(hospital_name);
			hs.setAttribute("listAvailable", availableList);
			RequestDispatcher rd=request.getRequestDispatcher("List.jsp");	
			pw.println("<h2 style=color:green;>Updated</h2>");
			rd.include(request, response);
			
			
		}else
		{
			RequestDispatcher rd=request.getRequestDispatcher("List.jsp");
			pw.println("<h2 style=color:red;>Approval Declined</h2>");
			rd.include(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
