package com.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cts.dao.DoctorDao;
import com.cts.dao.DoctorDaoImpl;
import com.cts.dao.HospitalRegistrationDao;
import com.cts.dao.HospitalRegistrationDaoImpl;
import com.cts.model.DoctorModel;
import com.cts.model.HospitalRegistrationModel;

import com.cts.service.HospitalRegistrationService;
import com.cts.service.HospitalRegistrationServiceImpl;


public class HospitalRegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 	public void init() throws ServletException {
 		System.out.println("Servlet Initialization");
 	}
 
 	
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	//Step 1 set the content type like html or xml or pdf or text or doc
	response.setContentType("text/html");

	
	//Step 2 create an out object using printWriter class
	PrintWriter out=response.getWriter();
	
	
	//Step 3 get the parameters from html/jsp form using getparameter
	int hospital_id=Integer.parseInt(request.getParameter("HospitalId"));
	String hospital_name=request.getParameter("HospitalName");
	String addr_line1=request.getParameter("AddressLine1");
	String addr_line2=request.getParameter("AddressLine2");
	String city=request.getParameter("City");
	String state=request.getParameter("State");
	int pin=Integer.parseInt(request.getParameter("Pin"));
	int certification=Integer.parseInt(request.getParameter("certification"));
	String success_operation=request.getParameter("SuccessfulOperations");
	int achievement=Integer.parseInt(request.getParameter("Achievement"));
    HospitalRegistrationModel dr=new HospitalRegistrationModel(hospital_id,hospital_name,addr_line1,addr_line2,city,state,pin,certification,success_operation,achievement);
    try {
        HospitalRegistrationDao drdao=new HospitalRegistrationDaoImpl();
        int count=drdao.register(dr);;
        if(count==1)
        {
                        out.println("<center><h2 style='color:green;'>Added Successfully</h2></center>");
                        request.getRequestDispatcher("HospitalLogin.jsp").include(request, response);
                        System.out.println("Added ");

        }
        else
        {
                        out.println("Failed Adding");
                        request.getRequestDispatcher("AddDoctor.jsp").include(request, response);
                        System.out.println("Failed");
        }
        }catch (Exception e) {
			// TODO: handle exception
        	System.out.println("Error in Insert Doctor COntroller : "+e);
		}
}
}


