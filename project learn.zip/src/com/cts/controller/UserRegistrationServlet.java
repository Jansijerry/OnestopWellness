package com.cts.controller;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.cts.model.UserRegistrationModel;
import com.cts.service.UserRegistrationService;
import com.cts.service.UserRegistrationServiceImpl;


public class UserRegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 	public void init() throws ServletException {
 		System.out.println("Servlet Initialization");
 	}
 
 	
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	//Step 1 set the content type like html or xml or pdf or text or doc
	response.setContentType("text/html");

	
	//Step 2 create an out object using printWriter class
	PrintWriter out=response.getWriter();
	
	
	//Step 3 get the parameters from html/jsp form using getparameter
	int userid=Integer.parseInt(request.getParameter("UserId"));
	String firstname=request.getParameter("FirstName");
	String lastname=request.getParameter("LastName");
	int age=Integer.parseInt(request.getParameter("age"));
	String gender=request.getParameter("gender");
	String contactnumber=request.getParameter("ContactNumber");
	String address=request.getParameter("Address");
	String city=request.getParameter("City");
	String zip_code=request.getParameter("Zipcode");
	String password=request.getParameter("Password");
	
	//Step 4 create an object for POJO/model class and  set the values
	UserRegistrationModel model1=new UserRegistrationModel();
	model1.setUserId(userid);
	model1.setFirstName(firstname);
	model1.setLastName(lastname);
	model1.setAge(age);
	model1.setGender(gender);
	model1.setContactNumber(contactnumber);
	model1.setAddress(address);
	model1.setCity(city);
	model1.setZipcode(zip_code);
	model1.setPassword(password);
	
	//Step 5 get the value from object of POJO/Model class and display on a Tomcat server
	out.print("<table border=1>");
	out.print("<tr>");
	out.print("<th>"+"UserID"+"</th>");
	out.print("<th>"+"FirstName"+"</th>");
	out.print("<th>"+"LastName"+"</th>");
	out.print("<th>"+"Age"+"</th>");
	out.print("<th>"+"Gender"+"</th>");
	out.print("<th>"+"Contact Number"+"</th>");
	out.print("<th>"+"Address"+"</th>");
	out.print("<th>"+"City"+"</th>");
	out.print("<th>"+"Zipcode"+"</th>");
	out.print("<th>"+"Password"+"</th>");
	out.print("</tr>");
	out.print("<tr>");
	out.print("<td>"+model1.getUserId()+"</td>");
	out.print("<td>"+model1.getFirstName()+"</td>");
	out.print("<td>"+model1.getLastName()+"</td>");
	out.print("<td>"+model1.getAge()+"</td>");
	out.print("<td>"+model1.getGender()+"</td>");
	out.print("<td>"+model1.getContactNumber()+"</td>");
	out.print("<td>"+model1.getAddress()+"</td>");
	out.print("<td>"+model1.getCity()+"</td>");
	out.print("<td>"+model1.getZipcode()+"</td>");
	out.print("<td>"+model1.getPassword()+"</td>");
	out.print("</tr>");
	out.print("</table>");
	

	//step 6:call service layer for database
	UserRegistrationService service=new UserRegistrationServiceImpl();
	service.register(model1);	
	out.print("Login has been successfully completed.");
}


public void destroy() {
	System.out.println("Destroy server or close the server");
	}



}
