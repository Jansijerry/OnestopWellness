package com.cts.service;

import com.cts.dao.HospitalRegistrationDao;
import com.cts.dao.HospitalRegistrationDaoImpl;
import com.cts.model.HospitalRegistrationModel;



public class HospitalRegistrationServiceImpl implements HospitalRegistrationService{
	
	public void register(HospitalRegistrationModel model) {
		// TODO Auto-generated method stub
		HospitalRegistrationDao dao=new HospitalRegistrationDaoImpl();
		dao.register(model);
		
	}
}
