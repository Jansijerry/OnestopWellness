package com.cts.service;

import com.cts.model.UserRegistrationModel;

public interface UserRegistrationService {
	public void register(UserRegistrationModel model);
}
