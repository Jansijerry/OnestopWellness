package com.cts.service;

import com.cts.model.HospitalLoginModel;

public interface HospitalLoginService {
	public boolean register(HospitalLoginModel model);
}
