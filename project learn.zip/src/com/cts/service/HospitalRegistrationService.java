package com.cts.service;

import com.cts.model.HospitalRegistrationModel;



public interface HospitalRegistrationService {
	public void register(HospitalRegistrationModel model);
}
