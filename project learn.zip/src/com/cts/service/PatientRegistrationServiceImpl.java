package com.cts.service;

import com.cts.dao.PatientRegistrationDao;
import com.cts.dao.PatientRegistrationDaoImpl;
import com.cts.model.PatientRegistrationModel;

public class PatientRegistrationServiceImpl implements PatientRegistrationService{

	@Override
	public void register(PatientRegistrationModel model) {
		// TODO Auto-generated method stub
		PatientRegistrationDao dao=new PatientRegistrationDaoImpl();
		dao.insertDiagnosis(model);
		
	}

}
