package com.cts.service;

import com.cts.dao.UserLoginDao;
import com.cts.dao.UserLoginDaoImpl;
import com.cts.model.UserLoginModel;

public class UserLoginServiceImpl implements UserLoginService {

	

	@Override
	public boolean register(UserLoginModel model) {
		// TODO Auto-generated method stub
		UserLoginDao dao=new UserLoginDaoImpl();
		
		return dao.register(model);
	}
	

}
