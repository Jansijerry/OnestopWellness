package com.cts.service;


import com.cts.dao.UserRegistrationDao;
import com.cts.dao.UserRegistrationDaoImpl;
import com.cts.model.UserRegistrationModel;

public class UserRegistrationServiceImpl implements UserRegistrationService {

	@Override
	public void register(UserRegistrationModel model) {
		// TODO Auto-generated method stub
		UserRegistrationDao dao=new UserRegistrationDaoImpl();
		dao.register(model);
		
	}

}
