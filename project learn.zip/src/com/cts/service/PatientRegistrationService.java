package com.cts.service;

import com.cts.model.PatientRegistrationModel;

public interface PatientRegistrationService {
	public void register(PatientRegistrationModel model);
}
