package com.cts.service;

import com.cts.model.UserLoginModel;


public interface UserLoginService {
	public boolean register(UserLoginModel model);
}
