package com.cts.service;

import com.cts.dao.HospitalLoginDao;
import com.cts.dao.HospitalLoginDaoImpl;
import com.cts.model.HospitalLoginModel;


public class HospitalLoginServiceImpl implements HospitalLoginService{

	@Override
	public boolean register(HospitalLoginModel model) {
		// TODO Auto-generated method stub
		HospitalLoginDao dao=new HospitalLoginDaoImpl();
		return dao.register(model);
		
	}
	
}
